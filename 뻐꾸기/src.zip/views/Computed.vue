<template>
<div>
    <h1>Full Name: {{fullName}}</h1>
</div>
  
</template>

<script>
export default {
    data(){
        return{
            firstName: 'Min Yeong',
            lastName : 'Kim'
        }
    },
    computed : {
        fullName(){ //firstName과 lastName을 합쳐 반환하는 함수
            return this.firstName + ' ' +this.lastName
        }
    }
}
</script>

<style>

</style>