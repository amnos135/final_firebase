<template>
  <div class="container" v-bind:class="{active : isActive, 'text-red':hasError}">
    class Binding
  </div>
</template>

<script>
export default {
    data(){
        return{
            isActive: true, //false로 바꾸면 노란색이 사라짐
            hasError: false //true로 바꾸면 빨간글자로 바뀜
         }
    }
}
</script>

<style scoped> /* scoped : 이거 적으면 다른파일의 클래스들에는 스타일 적용 안됨 */
    .container{
        width:100%;
        height: 200px;
    }
    .active{
        background-color:yellow;
        font-weight: bold;
    }
    .text-red{
        color: red;
    }
</style>