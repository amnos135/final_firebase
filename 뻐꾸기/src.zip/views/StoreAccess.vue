<template>
    <div>
        <p>Count : {{count}}</p>
        <p>cartCount : {{cartCount}}</p>
        <button type="button" @click="increment">Increment</button>
    </div>
</template>

<script>
export default {
    computed:{//vue인스턴스의 정의된 데이터 값에 변경이 일어났는지 감시하고 변경될 때 마다 정의된 함수가 실행되도록 
    count(){
        return this.$store.state.count; //스토어의 count를 감시해서 변경사항 적용
    },
    cartCount(){
        return this.$store.getters.cartCount; // 
    }

    },
    methods: {
        increment(){
            this.$store.commit('increment'); //commit()함수를 이용해 1씩 증가하는 함수
        }   
    }
}
</script>

<style>

</style>