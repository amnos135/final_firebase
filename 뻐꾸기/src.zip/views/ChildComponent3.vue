<template>
  <h1>{{ msg }}</h1>
</template>

<script>
export default {
    data(){
        return {
            msg:'' //데이터 정의
        }
    }
}
</script>

<style>

</style>