<template>
    <h1>Hello, {{title}}!</h1>
</template>
<script>
    export default {
        data() { //데이터에 정의된 title이 template의 {{}}에 바인딩 되는 구조이다.
            return {
                title:'World'
            };
        }
    }
</script>