<template>
    <div>
        <modal-layout>

            <template v-slot:header>
                <h1>팝업 타이틀</h1>
            </template>

            <template v-slot:default>
                <p>팝업컨텐츠1</p>
                <p>팝업컨텐츠2</p>
            </template>

            <template v-slot:footer>
                <button type="button">닫기</button>
            </template>

        </modal-layout>
    </div>
</template>

<script>
import ModalLayout from './SlotModalLayout.vue';
export default {
    components:{'modal-layout' : ModalLayout}
}
</script>

<style>

</style>