<template>
  <div>
    <button type="button" @click="childFunc" ref="btn">자식 컴포넌트 데이터 변경</button>
    <!-- ref="btn"은 특정 dom이나 컴포넌트의 정보(html)에 접근하기 위한 속성 -->
  </div>
</template>

<script>
export default {
    data(){
        return {
            msg: '메세지'
        }
    },
    methods: {
        childFunc() {
            this.msg = '변경된 메세지';
        }
    }
}
</script>

<style>

</style>