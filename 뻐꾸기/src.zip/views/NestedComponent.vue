 <template>
  <div>
      <PageTitle />
  </div>
</template>

<script>
    import PageTitle from '../components/PageTitle.vue' //1.컴포넌트 가져오기
    export default {
        components: {PageTitle} //2.현재 컴포넌트에서 사용할 컴포넌트를 등록하는 
    }
</script>