<template>
<div>
    <h1>Full Name : {{fullName}}</h1>
</div> 
</template>

<script>
export default {
    data(){
        return{
            firstName: 'Min Yeong',
            lastName : 'Kim',
            fullname: ''
        }
    },
    watch: {
        firstName(){
            this.fullName=this.firstName + ' ' + this.lastName
        },
        lastName(){
            this.fullName=this.firstName + ' ' + this.lastName
        }
    }
}
     
</script>

<style>

</style>