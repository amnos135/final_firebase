<template>
    <div v-bind:style="[baseStyle, addStyle]">
        인라인 스타일 바인딩2 (파란색글자)
    </div>
</template>

<script>
export default {
    data(){
        return{
            baseStyle : 'background-color:yellow; width:50%; height:100px;',
            addStyle: 'color:blue; font-weight:bold;'
         }
    }
}
</script>

<style scoped>  
    

</style>