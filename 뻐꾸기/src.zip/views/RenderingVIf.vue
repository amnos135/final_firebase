<template>
<div>
    <h1 v-if="type=='a'">a</h1>
    <h1 v-else-if="type=='b'">b</h1>
    <h1 v-else>c</h1>
    
</div>
</template>

<script>
export default {
    data(){
        return{
            type : 'a'
          }
    }
}
</script>

<style>


</style>