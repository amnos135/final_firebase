<template>
  <h2>{{title}}</h2>
</template>

<script>
export default {
    props : { //부모 컴포넌트로 전달받은 데이터가 저장됨
        title: {
            type : String,
            default : "페이지 제목입니다." //부모로부터 데이터가 전달되지 않았을 때의 값
        }
    }
}
</script>

<style>

</style>