import { createWebHistory, createRouter } from "vue-router"
import HomeView from './views/HomeView.vue'
import DataBinding from './views/DataBinding.vue'
import NestedComponent from './views/NestedComponent.vue'

const routes = [
    {
        path: "/", //경로
        name: 'HomeView',
        component: HomeView, //2번째줄에 import해온 컴포넌트,
    },
    {
        path: "/databinding",  
        name: 'Databinding',
        component: DataBinding,  //3번째줄에 import해온 컴포넌트,
    },
    {
        path: "/databindinghtml",  
        name: 'Databindinghtml',
        component: () => import(/* webpackChunkName: "databindinghtml" */
        './views/DataBindingHtml.vue'
        )    
    },
    {
        path: "/DataBindingInputText",  
        name: 'Data-binding-input-text',
        component: () => import(/* webpackChunkName: "databindinghtml" */
        './views/DataBindingInputText.vue'
        )    
    },
    {
        path: "/DataBindingInputNumber",  
        name: 'DataBindingInputNumber',
        component: () => import(/* webpackChunkName: "databindinghtml" */
        './views/DataBindingInputNumber.vue'
        )    
    },
    {
        path: "/databindingtextarea",  
        name: 'databindingtextarea',
        component: () => import(/* webpackChunkName: "databindinghtml" */
        './views/DataBindingTextarea.vue'
        )    
    },
    {
        path: "/databindingselect",  
        name: 'databindingselect',
        component: () => import(/* webpackChunkName: "databindinghtml" */
        './views/DataBindingSelect.vue'
        )    
    },
    {
        path: "/databindingcheckbox",  
        name: 'databindingcheckbox',
        component: () => import(/* webpackChunkName: "databindinghtml" */
        './views/DataBindingCheckbox.vue'
        )    
    },
    {
        path: "/databindingcheckbox2",  
        name: 'databindingcheckbox2',
        component: () => import(/* webpackChunkName: "databindinghtml" */
        './views/DataBindingCheckbox2.vue'
        )    
    },
    {
        path: "/databindingradio",  
        name: 'databindingradio',
        component: () => import(/* webpackChunkName: "databindinghtml" */
        './views/DataBindingRadio.vue'
        )    
    },
    {
        path: "/databindingattribute",  
        name: 'databindingattribute',
        component: () => import(/* webpackChunkName: "databindinghtml" */
        './views/DataBindingAttribute.vue'
        )    
    },
    {
        path: "/databindingbutton",  
        name: 'databindingbutton',
        component: () => import(/* webpackChunkName: "databindinghtml" */
        './views/DataBindingButton.vue'
        )    
    },
    {
        path: "/databindingclass",  
        name: 'databindingclass',
        component: () => import(/* webpackChunkName: "databindinghtml" */
        './views/DataBindingClass.vue'
        )    
    },
    {
        path: "/databindingclass2",  
        name: 'databindingclass2',
        component: () => import(/* webpackChunkName: "databindinghtml" */
        './views/DataBindingClass2.vue'
        )    
    },
    {
        path: "/databindingstyle",  
        name: 'databindingstyle',
        component: () => import(/* webpackChunkName: "databindinghtml" */
        './views/DataBindingStyle.vue'
        )    
    },
    {
        path: "/databindingstyle2",  
        name: 'databindingstyle2',
        component: () => import(/* webpackChunkName: "databindinghtml" */
        './views/DataBindingStyle2.vue'
        )    
    },
    {
        path: "/databindinglist",  
        name: 'databindinglist',
        component: () => import(/* webpackChunkName: "databindinghtml" */
        './views/DataBindingList.vue'
        )    
    },
    {
        path: "/renderingVif",  
        name: 'renderingVif',
        component: () => import(/* webpackChunkName: "databindinghtml" */
        './views/RenderingVIf.vue'
        )    
    },
    {
        path: "/eventClick",  
        name: 'EventClick',
        component: () => import(/* webpackChunkName: "databindinghtml" */
        './views/EventClick.vue'
        )    
    },
    {
        path: "/eventChange",  
        name: 'EventChange',
        component: () => import(/* webpackChunkName: "databindinghtml" */
        './views/EventChange.vue'
        )    
    },
    {
        path: "/computed",  
        name: 'computed',
        component: () => import(/* webpackChunkName: "databindinghtml" */
        './views/Computed.vue'
        )    
    },
    {
        path: "/watch",  
        name: 'watch',
        component: () => import(/* webpackChunkName: "databindinghtml" */
        './views/Watch.vue'
        )    
    },
    {
        path: "/watch2",  
        name: 'watch2',
        component: () => import(/* webpackChunkName: "databindinghtml" */
        './views/Watch2.vue'
        )    
    },
    {
        path: "/dataBindingList2",  
        name: 'dataBindingList2',
        component: () => import(/* webpackChunkName: "databindinghtml" */
        './views/DataBindingList2.vue'
        )    
    },
    {
        path: "/nested",  
        name: 'NestedComponent',
        component:NestedComponent  
    },
    {
        path: "/parent",  
        name: 'ParentComponent',
        component: () => import(/* webpackChunkName: "databindinghtml" */
        './views/ParentComponent.vue'
        )  
    },
    {
        path: "/parent2",  
        name: 'ParentComponent2',
        component: () => import(/* webpackChunkName: "databindinghtml" */
        './views/ParentComponent2.vue'
        )  
    },
    {
        path: "/parent3",  
        name: 'ParentComponent3',
        component: () => import(/* webpackChunkName: "databindinghtml" */
        './views/ParentComponent3.vue'
        )  
    },
    {
        path: "/parent4",  
        name: 'ParentComponent4',
        component: () => import(/* webpackChunkName: "ParentComponent4" */
        './views/ParentComponent4.vue'
        )  
    },
    {
        path: "/parent5",  
        name: 'ParentComponent5',
        component: () => import(/* webpackChunkName: "ParentComponent5" */
        './views/ParentComponent5.vue'
        )  
    },
    {
        path: "/slotuse",  
        name: 'SlotUseModalLayout',
        component: () => import(/* webpackChunkName: "slotModalLayout" */
        './views/SlotUseModalLayout.vue'
        )  
    },
    {
        path: "/store",  
        name: 'storeaccess',
        component: () => import(/* webpackChunkName: "slotModalLayout" */
        './views/StoreAccess.vue'
        )  
    },
    {
        path: "/kakaologin",  
        name: 'KaKaoLogin',
        component: () => import(/* webpackChunkName: "slotModalLayout" */
        './views/KaKaoLogin.vue'
        )  
    }

];

const router = createRouter({
    history: createWebHistory(process.env.BASE_URL),
    routes
});

export default router; //위에서 import한 파일들을 내보내기